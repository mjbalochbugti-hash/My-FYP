const API = "http://localhost:5000/api";
const getToken = () => localStorage.getItem("ss_token");
const setToken = t => localStorage.setItem("ss_token", t);
const authHdr  = () => { const t = getToken(); return t ? { "Authorization": "Bearer " + t } : {}; };
const logout   = () => { localStorage.removeItem("ss_token"); window.location.href = "login.html"; };
