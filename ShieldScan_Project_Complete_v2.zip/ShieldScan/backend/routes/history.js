const express = require("express");
const auth = require("../middleware/authMiddleware");
const { readDB } = require("../utils/db");
const router = express.Router();

router.get("/", auth, (req, res) => {
  const db = readDB();
  const history = db.history
    .filter(h => h.userId === req.user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ history });
});

module.exports = router;
