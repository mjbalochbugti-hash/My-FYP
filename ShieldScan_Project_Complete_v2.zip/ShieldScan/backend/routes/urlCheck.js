const express = require("express");
const { readDB, writeDB } = require("../utils/db");
const router = express.Router();

const BAD_TLDS = [".tk", ".xyz", ".top", ".gq", ".ml", ".cf", ".click", ".loan", ".work"];
const SHORTENERS = ["bit.ly", "tinyurl.com", "goo.gl", "t.co", "is.gd", "ow.ly"];
const BRANDS = ["paypal", "google", "facebook", "apple", "microsoft", "amazon", "netflix", "bank", "easypaisa", "jazzcash"];

function heuristic(url) {
  const reasons = [];
  let pts = 0;
  let host = "";
  try { host = new URL(url).hostname.toLowerCase(); }
  catch { return { status: "suspicious", reasons: ["Invalid URL format."], confidence: 60 }; }
  if (!url.startsWith("https://")) { reasons.push("No HTTPS — connection is not encrypted."); pts += 25; }
  if (BAD_TLDS.some(t => host.endsWith(t))) { reasons.push(`Domain uses suspicious TLD (.${host.split(".").pop()}).`); pts += 30; }
  if (SHORTENERS.some(s => host.includes(s))) { reasons.push("Shortened URL — real destination is hidden."); pts += 20; }
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) { reasons.push("URL uses a raw IP address instead of a domain."); pts += 25; }
  if (/-{2,}/.test(host) || /\d{5,}/.test(host)) { reasons.push("Domain contains unusual character patterns."); pts += 10; }
  const brand = BRANDS.find(b => host.includes(b) && !host.endsWith(b + ".com") && !host.endsWith(b + ".pk"));
  if (brand) { reasons.push(`Possible phishing — imitates "${brand}" but is not the official site.`); pts += 35; }
  if (!reasons.length) reasons.push("No suspicious patterns detected.");
  const status = pts >= 50 ? "malicious" : pts >= 20 ? "suspicious" : "safe";
  return { status, reasons, confidence: Math.min(pts + 20, 95) };
}

function saveHistory(req, target, result) {
  try {
    const jwt = require("jsonwebtoken");
    const h = req.headers.authorization;
    if (!h) return;
    const user = jwt.verify(h.split(" ")[1], process.env.JWT_SECRET || "shieldscan_secret");
    const db = readDB();
    db.history.push({ id: Date.now().toString(), userId: user.id, type: "url", target, result, createdAt: new Date().toISOString() });
    writeDB(db);
  } catch {}
}

router.post("/", async (req, res) => {
  let { url } = req.body;
  if (!url) return res.status(400).json({ error: "Please provide a URL." });
  if (!/^https?:\/\//i.test(url)) url = "http://" + url;
  const result = heuristic(url);
  result.url = url;
  saveHistory(req, url, result);
  res.json(result);
});

module.exports = router;
