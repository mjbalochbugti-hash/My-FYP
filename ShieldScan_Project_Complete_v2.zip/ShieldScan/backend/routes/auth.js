const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { readDB, writeDB } = require("../utils/db");
const auth = require("../middleware/authMiddleware");
const router = express.Router();
const SECRET = () => process.env.JWT_SECRET || "shieldscan_secret";

router.post("/signup", async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password)
    return res.status(400).json({ error: "All fields required." });
  const db = readDB();
  if (db.users.find(u => u.email === email))
    return res.status(409).json({ error: "Email already registered." });
  const passwordHash = await bcrypt.hash(password, 10);
  const user = { id: Date.now().toString(), name, email, passwordHash, createdAt: new Date().toISOString() };
  db.users.push(user);
  writeDB(db);
  const token = jwt.sign({ id: user.id, name: user.name, email: user.email }, SECRET(), { expiresIn: "7d" });
  res.status(201).json({ message: "Account created!", token });
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ error: "Email and password required." });
  const db = readDB();
  const user = db.users.find(u => u.email === email);
  if (!user || !(await bcrypt.compare(password, user.passwordHash)))
    return res.status(401).json({ error: "Invalid email or password." });
  const token = jwt.sign({ id: user.id, name: user.name, email: user.email }, SECRET(), { expiresIn: "7d" });
  res.json({ message: "Login successful.", token });
});

router.get("/me", auth, (req, res) => res.json({ user: req.user }));

module.exports = router;
