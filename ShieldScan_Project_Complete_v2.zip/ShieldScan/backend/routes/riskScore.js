const express = require("express");
const axios = require("axios");
const { readDB, writeDB } = require("../utils/db");
const router = express.Router();
const BAD_TLDS = [".tk", ".xyz", ".top", ".gq", ".ml", ".cf"];

function saveHistory(req, target, result) {
  try {
    const jwt = require("jsonwebtoken");
    const h = req.headers.authorization;
    if (!h) return;
    const user = jwt.verify(h.split(" ")[1], process.env.JWT_SECRET || "shieldscan_secret");
    const db = readDB();
    db.history.push({ id: Date.now().toString(), userId: user.id, type: "risk", target, result, createdAt: new Date().toISOString() });
    writeDB(db);
  } catch {}
}

router.post("/", async (req, res) => {
  const { target } = req.body;
  if (!target) return res.status(400).json({ error: "Provide an IP or domain." });
  let score = 10;
  const factors = [];
  try {
    if (/^(\d{1,3}\.){3}\d{1,3}$/.test(target)) {
      const { data: g } = await axios.get(`http://ip-api.com/json/${target}?fields=status,message,proxy,hosting`);
      if (g.status === "fail") return res.status(400).json({ error: "Cannot resolve this IP." });
      if (g.proxy)   { score += 30; factors.push("IP is associated with a VPN or Proxy service."); }
      if (g.hosting) { score += 20; factors.push("IP belongs to a datacenter/hosting provider."); }
      if (!g.proxy && !g.hosting) factors.push("IP appears to be a normal residential address.");
    } else {
      const domain = target.replace(/^https?:\/\//, "").split("/")[0];
      if (BAD_TLDS.some(t => domain.endsWith(t))) { score += 35; factors.push("Domain TLD commonly used for scam/phishing."); }
      else factors.push("Domain TLD appears normal and commonly trusted.");
      if (domain.length > 30) { score += 10; factors.push("Unusually long domain name."); }
      if (!target.startsWith("https")) { score += 15; factors.push("No HTTPS detected."); }
    }
  } catch { return res.status(500).json({ error: "Risk calculation failed." }); }
  score = Math.min(score, 100);
  const recommendation = score >= 60
    ? "High risk — avoid sharing data or clicking links from this source."
    : score >= 30
    ? "Medium risk — proceed with caution and verify the source."
    : "Low risk — this target appears safe to interact with.";
  const result = { target, score, factors, recommendation };
  saveHistory(req, target, result);
  res.json(result);
});

module.exports = router;
