const express = require("express");
const axios = require("axios");
const { readDB, writeDB } = require("../utils/db");
const router = express.Router();

function saveHistory(req, target, result) {
  try {
    const jwt = require("jsonwebtoken");
    const h = req.headers.authorization;
    if (!h) return;
    const user = jwt.verify(h.split(" ")[1], process.env.JWT_SECRET || "shieldscan_secret");
    const db = readDB();
    db.history.push({ id: Date.now().toString(), userId: user.id, type: "ip", target, result, createdAt: new Date().toISOString() });
    writeDB(db);
  } catch {}
}

router.post("/", async (req, res) => {
  const { ip } = req.body;
  if (!ip || !/^(\d{1,3}\.){3}\d{1,3}$/.test(ip))
    return res.status(400).json({ error: "Enter a valid IPv4 address." });
  try {
    const { data: g } = await axios.get(`http://ip-api.com/json/${ip}?fields=status,message,country,city,region,isp,org,as,proxy,hosting,query`);
    if (g.status === "fail") return res.status(400).json({ error: g.message || "Could not resolve IP." });
    let abuseScore = g.proxy || g.hosting ? 55 : 5;
    const threatLevel = abuseScore >= 75 ? "high" : abuseScore >= 30 ? "medium" : "low";
    const result = { ip: g.query, country: g.country, city: g.city, region: g.region, isp: g.isp, org: g.org, asn: g.as, isVpnOrProxy: !!g.proxy, isHosting: !!g.hosting, abuseScore, threatLevel };
    saveHistory(req, ip, result);
    res.json(result);
  } catch {
    res.status(500).json({ error: "IP scan failed. Please try again." });
  }
});

module.exports = router;
