const jwt = require("jsonwebtoken");

module.exports = (req, res, next) => {
  const h = req.headers.authorization;
  if (!h || !h.startsWith("Bearer "))
    return res.status(401).json({ error: "No token. Please login." });
  try {
    req.user = jwt.verify(h.split(" ")[1], process.env.JWT_SECRET || "shieldscan_secret");
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired token." });
  }
};
