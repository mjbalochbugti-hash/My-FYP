const fs = require("fs");
const path = require("path");
const DB = path.join(__dirname, "..", "data", "db.json");

function readDB() {
  if (!fs.existsSync(DB)) {
    const d = { users: [], history: [] };
    fs.writeFileSync(DB, JSON.stringify(d, null, 2));
    return d;
  }
  return JSON.parse(fs.readFileSync(DB, "utf-8"));
}

function writeDB(data) {
  fs.writeFileSync(DB, JSON.stringify(data, null, 2));
}

module.exports = { readDB, writeDB };
